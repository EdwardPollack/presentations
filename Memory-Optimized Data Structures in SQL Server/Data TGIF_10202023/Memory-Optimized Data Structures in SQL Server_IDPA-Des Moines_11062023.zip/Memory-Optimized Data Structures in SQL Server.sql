USE WideWorldImporters;
GO
------------------------------------------------------------------------------------------------------------------------------
-------------------------Memory-Optimized Table Configuration-----------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
-- Features and performance are based on compatability level.  Latest and greatest is 100% worthwhile for this feature.
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 160; -- SQL Server 2022
GO

-- Snapshot isolation is required for memory-optimized tables.
ALTER DATABASE WideWorldImporters SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON;
GO

-- Check for existing memory-optimized filegroup:
SELECT
	*
FROM sys.filegroups
WHERE filegroups.[type_desc] = 'MEMORY_OPTIMIZED_DATA_FILEGROUP';

-- Create an in-memory filegroup (if one does not already exist)
ALTER DATABASE WideWorldImporters ADD FILEGROUP WideWorldImporters_IMOLTP
CONTAINS MEMORY_OPTIMIZED_DATA;
GO

-- Check for an existing memory-optimized file:
SELECT
	*
FROM sys.database_files
WHERE database_files.[type_desc] = 'FILESTREAM';

-- Create a physical file for in-memory objects.  Its contents vary depending on durability.
ALTER DATABASE WideWorldImporters ADD FILE (NAME='WWI_InMemory_Data_1', FILENAME = 'C:\SQLData\WWI_InMemory_Data_1')
TO FILEGROUP WWI_InMemory_Data;
GO

------------------------------------------------------------------------------------------------------------------------------
-------------------------Memory-Optimized Table Creation/Usage----------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
USE AdventureWorks2017;
GO

ALTER DATABASE AdventureWorks2017 SET COMPATIBILITY_LEVEL = 160; -- SQL Server 2022
GO
-- Snapshot isolation is required for memory-optimized tables.
ALTER DATABASE AdventureWorks2017 SET MEMORY_OPTIMIZED_ELEVATE_TO_SNAPSHOT = ON;
GO
-- Create a filegroup and file for our memory-optimized table:
ALTER DATABASE AdventureWorks2017 ADD FILEGROUP AdventureWorks2017IMOLTP CONTAINS MEMORY_OPTIMIZED_DATA;
-- Add a file to the new filegroup
ALTER DATABASE AdventureWorks2017 ADD FILE (NAME='AdventureWorks2017_IMOLTP', FILENAME='c:\SqlData\AdventureWorks2017_IMOLTP') TO FILEGROUP AdventureWorks2017IMOLTP;
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'get_email_address_data')
	DROP PROCEDURE dbo.get_email_address_data;
GO

-- Create a standard disk-based stored procedure that collects data from Person.EmailAddress
CREATE PROCEDURE dbo.get_email_address_data
	(@BusinessEntityID INT = NULL)
AS
BEGIN
	IF @BusinessEntityID IS NULL
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM Person.EmailAddress;
	END
	ELSE
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM person.EmailAddress
		WHERE BusinessEntityID = @BusinessEntityID;
	END
END
GO

DBCC FREEPROCCACHE;
DBCC DROPCLEANBUFFERS;
SET STATISTICS IO ON;
SET STATISTICS TIME ON;

EXEC get_email_address_data @BusinessEntityID = 12894;

-- Create a new email address table using in-memory OLTP
CREATE TABLE Person.EmailAddress_IMOLTP(
	BusinessEntityID INT NOT NULL PRIMARY KEY NONCLUSTERED HASH WITH (BUCKET_COUNT = 30000),
	EmailAddressID INT,
	EmailAddress NVARCHAR(50) COLLATE Latin1_General_BIN2 NOT NULL INDEX ix_EmailAddress NONCLUSTERED HASH(EmailAddress) WITH (BUCKET_COUNT = 30000),
	rowguid UNIQUEIDENTIFIER  NOT NULL CONSTRAINT DF_EmailAddress_IMOLTP_rowguid DEFAULT (NEWID()),
	ModifiedDate DATETIME NOT NULL CONSTRAINT DF_EmailAddress_IMOLTP_ModifiedDate DEFAULT (GETDATE()))
WITH (MEMORY_OPTIMIZED = ON, DURABILITY = SCHEMA_AND_DATA);
GO

INSERT INTO Person.EmailAddress_IMOLTP
(
	BusinessEntityID,
	EmailAddressID,
	EmailAddress,
	rowguid,
	ModifiedDate
)
SELECT
	BusinessEntityID,
	EmailAddressID,
	EmailAddress,
	rowguid,
	ModifiedDate
FROM person.EmailAddress
ORDER BY EmailAddressID;

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'get_email_address_data_IMOLTP')
	DROP PROCEDURE dbo.get_email_address_data_IMOLTP
GO

-- Create a standard disk-based stored procedure that collects data from Person.EmailAddress
CREATE PROCEDURE dbo.get_email_address_data_IMOLTP
	(@BusinessEntityID INT = NULL)
AS
BEGIN
	IF @BusinessEntityID IS NULL
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM Person.EmailAddress_IMOLTP
	END
	ELSE
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM person.EmailAddress_IMOLTP
		WHERE BusinessEntityID = @BusinessEntityID
	END
END
GO

EXEC get_email_address_data @BusinessEntityID = 12894
GO

-- Note no IO, but is not a natively-compiled stored procedure (yet)
EXEC get_email_address_data_IMOLTP @BusinessEntityID = 12894
GO

------------------------------------------------------------------------------------------------------------------------------
-------------------------Memory-optimized Table Variables---------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
USE AdventureWorks2017;
GO

-- A memory-optimized table type is required for memory-optimized table variables.
CREATE TYPE dbo.SalesOrderHeader_Temp_IMOLTP
AS TABLE
(	[SalesOrderID] [int] PRIMARY KEY NONCLUSTERED,
	[RevisionNumber] [tinyint] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[ShipDate] [datetime] NULL,
	[Status] [tinyint] NOT NULL,
	[OnlineOrderFlag] BIT NOT NULL,
	[SalesOrderNumber] NVARCHAR(25),
	[PurchaseOrderNumber] NVARCHAR(25) NULL,
	[AccountNumber] NVARCHAR(15) NULL,
	[CustomerID] [int] NOT NULL,
	[SalesPersonID] [int] NULL,
	[TerritoryID] [int] NULL,
	[BillToAddressID] [int] NOT NULL,
	[ShipToAddressID] [int] NOT NULL,
	[ShipMethodID] [int] NOT NULL,
	[CreditCardID] [int] NULL,
	[CreditCardApprovalCode] [varchar](15) NULL,
	[CurrencyRateID] [int] NULL,
	[SubTotal] [money] NOT NULL,
	[TaxAmt] [money] NOT NULL,
	[Freight] [money] NOT NULL,
	[TotalDue] MONEY,
	[Comment] [nvarchar](128) NULL,
	[rowguid] [uniqueidentifier] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	INDEX IX_SalesOrderHeader_Temp_IMOLTP_CustomerID NONCLUSTERED HASH (CustomerID) WITH (BUCKET_COUNT = 25000)
)
WITH (MEMORY_OPTIMIZED = ON);
GO

CREATE TYPE dbo.SalesOrderDetail_Temp_IMOLTP
AS TABLE
(	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal] DECIMAL(38,6),
	[rowguid] [uniqueidentifier] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	INDEX IX_SalesOrderDetail_Temp_IMOLTP_SalesOrderID_SalesOrderDetailID NONCLUSTERED HASH (SalesOrderID, SalesOrderDetailID) WITH (BUCKET_COUNT = 125000)
)
WITH (MEMORY_OPTIMIZED = ON);
GO

-- Compare standard table variables vs. in-memory table variables.

-- Test queries for classic table variables:
-- Declare standard table variables identical to the ones above:
DECLARE @SalesOrderHeader_Temp TABLE
(	[SalesOrderID] [INT] PRIMARY KEY CLUSTERED,
	[RevisionNumber] [TINYINT] NOT NULL,
	[OrderDate] [DATETIME] NOT NULL,
	[DueDate] [DATETIME] NOT NULL,
	[ShipDate] [DATETIME] NULL,
	[Status] [TINYINT] NOT NULL,
	[OnlineOrderFlag] BIT NOT NULL,
	[SalesOrderNumber] NVARCHAR(25),
	[PurchaseOrderNumber] NVARCHAR(25) NULL,
	[AccountNumber] NVARCHAR(15) NULL,
	[CustomerID] [INT] NOT NULL INDEX IX_SalesOrderHeader_Temp_CustomerID NONCLUSTERED,
	[SalesPersonID] [INT] NULL,
	[TerritoryID] [INT] NULL,
	[BillToAddressID] [INT] NOT NULL,
	[ShipToAddressID] [INT] NOT NULL,
	[ShipMethodID] [INT] NOT NULL,
	[CreditCardID] [INT] NULL,
	[CreditCardApprovalCode] [VARCHAR](15) NULL,
	[CurrencyRateID] [INT] NULL,
	[SubTotal] [MONEY] NOT NULL,
	[TaxAmt] [MONEY] NOT NULL,
	[Freight] [MONEY] NOT NULL,
	[TotalDue] MONEY,
	[Comment] [NVARCHAR](128) NULL,
	[rowguid] [UNIQUEIDENTIFIER] NOT NULL,
	[ModifiedDate] [DATETIME] NOT NULL)
DECLARE @SalesOrderDetail_Temp TABLE
(	[SalesOrderID] [int] NOT NULL,
	[SalesOrderDetailID] [int] NOT NULL,
	[CarrierTrackingNumber] [nvarchar](25) NULL,
	[OrderQty] [smallint] NOT NULL,
	[ProductID] [int] NOT NULL,
	[SpecialOfferID] [int] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[UnitPriceDiscount] [money] NOT NULL,
	[LineTotal] DECIMAL(38,6),
	[rowguid] [uniqueidentifier] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
	INDEX IX_SalesOrderDetail_Temp_SalesOrderID_SalesOrderDetailID NONCLUSTERED (SalesOrderID, SalesOrderDetailID)
);
SET STATISTICS IO ON;
PRINT 'INSERT INTO @SalesOrderHeader_Temp';
-- Populate test order header data
INSERT INTO @SalesOrderHeader_Temp
SELECT TOP 10000
	[SalesOrderID], [RevisionNumber], [OrderDate], [DueDate], [ShipDate], [Status], [OnlineOrderFlag], [SalesOrderNumber], [PurchaseOrderNumber],
	[AccountNumber], [CustomerID], [SalesPersonID], [TerritoryID], [BillToAddressID], [ShipToAddressID], [ShipMethodID], [CreditCardID], [CreditCardApprovalCode],
	[CurrencyRateID], [SubTotal], [TaxAmt], [Freight], [TotalDue], [Comment], [rowguid], [ModifiedDate]
FROM sales.SalesOrderHeader;
PRINT 'INSERT INTO @SalesOrderDetail_Temp';
-- Populate test order detail data
INSERT INTO @SalesOrderDetail_Temp
SELECT
	[SalesOrderID], [SalesOrderDetailID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], 
	[UnitPriceDiscount], [LineTotal], [rowguid], [ModifiedDate]
FROM sales.SalesOrderDetail
WHERE SalesOrderDetail.SalesOrderID IN
	(SELECT SalesOrderHeader_Temp.SalesOrderID FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp);
-- Perform update against temp table using a seek/scan combination.
PRINT 'UPDATE SalesOrderDetail_Temp';
UPDATE SalesOrderDetail_Temp
	SET OrderQty = 2
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
INNER JOIN @SalesOrderDetail_Temp SalesOrderDetail_Temp
ON SalesOrderHeader_Temp.SalesOrderID = SalesOrderDetail_Temp.SalesOrderID 
WHERE SalesOrderHeader_Temp.CustomerID = 29707
AND SalesOrderDetail_Temp.OrderQty = 1;
-- Perform an insert against the detail table
PRINT 'INSERT INTO @SalesOrderDetail_Temp';
INSERT INTO @SalesOrderDetail_Temp
SELECT
	SalesOrderDetail_Temp.*
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
INNER JOIN @SalesOrderDetail_Temp SalesOrderDetail_Temp
ON SalesOrderHeader_Temp.SalesOrderID = SalesOrderDetail_Temp.SalesOrderID
WHERE SalesOrderHeader_Temp.CustomerID = 29707
AND SalesOrderHeader_Temp.SalesPersonID = 277;
-- Perform update against one temp table
UPDATE SalesOrderHeader_Temp
	SET Status = 1
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
WHERE SalesOrderHeader_Temp.CustomerID = 29707
AND SalesOrderHeader_Temp.Status = 5
AND SalesOrderHeader_Temp.PurchaseOrderNumber = 'PO2813140706';
-- Perform a join between a disk table and the temp table and write back to disk.
UPDATE SalesOrderDetail
	SET OrderQty = SalesOrderDetail_Temp.OrderQty
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
INNER JOIN @SalesOrderDetail_Temp SalesOrderDetail_Temp
ON SalesOrderHeader_Temp.SalesOrderID = SalesOrderDetail_Temp.SalesOrderID
INNER JOIN sales.SalesOrderDetail
ON SalesOrderDetail_Temp.SalesOrderDetailID = SalesOrderDetail.SalesOrderDetailID
AND SalesOrderDetail_Temp.SalesOrderID = SalesOrderDetail.SalesOrderID
WHERE SalesOrderHeader_Temp.CustomerID = 29707
AND SalesOrderHeader_Temp.SalesPersonID = 277;
-- Perform a join between a disk table and return rows to SSMS
SELECT
	SalesOrderHeader_Temp.SalesOrderID,
	SalesOrderDetail.SalesOrderDetailID,
	SalesOrderDetail.OrderQty,
	SalesOrderDetail_Temp.OrderQty
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
INNER JOIN @SalesOrderDetail_Temp SalesOrderDetail_Temp
ON SalesOrderHeader_Temp.SalesOrderID = SalesOrderDetail_Temp.SalesOrderID
INNER JOIN sales.SalesOrderDetail
ON SalesOrderDetail_Temp.SalesOrderDetailID = SalesOrderDetail.SalesOrderDetailID
AND SalesOrderDetail_Temp.SalesOrderID = SalesOrderDetail.SalesOrderID
WHERE SalesOrderHeader_Temp.CustomerID = 29707
AND SalesOrderHeader_Temp.SalesPersonID = 277;
-- Perform a join/select/seek against our data set
SELECT
	*
FROM @SalesOrderHeader_Temp SalesOrderHeader_Temp
INNER JOIN @SalesOrderDetail_Temp SalesOrderDetail_Temp
ON SalesOrderHeader_Temp.SalesOrderID = SalesOrderDetail_Temp.SalesOrderID
WHERE SalesOrderHeader_Temp.CustomerID = 29707;

-- Total reads: 63,859

-- Memory-optimized table example:
DECLARE @SalesOrderHeader_Temp_IMOLTP dbo.SalesOrderHeader_Temp_IMOLTP;
DECLARE @SalesOrderDetail_Temp_IMOLTP dbo.SalesOrderDetail_Temp_IMOLTP;

SET STATISTICS IO ON;
PRINT 'INSERT INTO @SalesOrderHeader_Temp_IMOLTP';
-- Populate test order header data
INSERT INTO @SalesOrderHeader_Temp_IMOLTP
SELECT TOP 10000
	[SalesOrderID], [RevisionNumber], [OrderDate], [DueDate], [ShipDate], [Status], [OnlineOrderFlag], [SalesOrderNumber], [PurchaseOrderNumber],
	[AccountNumber], [CustomerID], [SalesPersonID], [TerritoryID], [BillToAddressID], [ShipToAddressID], [ShipMethodID], [CreditCardID], [CreditCardApprovalCode],
	[CurrencyRateID], [SubTotal], [TaxAmt], [Freight], [TotalDue], [Comment], [rowguid], [ModifiedDate]
FROM sales.SalesOrderHeader;
-- Populate test order detail data
PRINT 'INSERT INTO @SalesOrderDetail_Temp_IMOLTP';
INSERT INTO @SalesOrderDetail_Temp_IMOLTP
SELECT
	[SalesOrderID], [SalesOrderDetailID], [CarrierTrackingNumber], [OrderQty], [ProductID], [SpecialOfferID], [UnitPrice], 
	[UnitPriceDiscount], [LineTotal], [rowguid], [ModifiedDate]
FROM sales.SalesOrderDetail
WHERE SalesOrderDetail.SalesOrderID IN
	(SELECT SalesOrderHeader_Temp_IMOLTP.SalesOrderID FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP);
-- Perform update against temp table using a seek/scan combination.
PRINT 'UPDATE SalesOrderDetail_Temp_IMOLTP';
UPDATE SalesOrderDetail_Temp_IMOLTP
	SET OrderQty = 2
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
INNER JOIN @SalesOrderDetail_Temp_IMOLTP SalesOrderDetail_Temp_IMOLTP
ON SalesOrderHeader_Temp_IMOLTP.SalesOrderID = SalesOrderDetail_Temp_IMOLTP.SalesOrderID 
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
AND SalesOrderDetail_Temp_IMOLTP.OrderQty = 1;
-- Perform an insert against the detail table
PRINT 'INSERT INTO @SalesOrderDetail_Temp_IMOLTP';
INSERT INTO @SalesOrderDetail_Temp_IMOLTP
SELECT
	SalesOrderDetail_Temp_IMOLTP.*
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
INNER JOIN @SalesOrderDetail_Temp_IMOLTP SalesOrderDetail_Temp_IMOLTP
ON SalesOrderHeader_Temp_IMOLTP.SalesOrderID = SalesOrderDetail_Temp_IMOLTP.SalesOrderID
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
AND SalesOrderHeader_Temp_IMOLTP.SalesPersonID = 277;
-- Perform update against one temp table
UPDATE SalesOrderHeader_Temp_IMOLTP
	SET Status = 5
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
-- Perform update against one temp table
UPDATE SalesOrderHeader_Temp_IMOLTP
	SET Status = 1
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
AND SalesOrderHeader_Temp_IMOLTP.Status = 5
AND SalesOrderHeader_Temp_IMOLTP.PurchaseOrderNumber = 'PO2813140706';
-- Perform a join between a disk table and the temp table and write back to disk.
UPDATE SalesOrderDetail
	SET OrderQty = SalesOrderDetail_Temp_IMOLTP.OrderQty
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
INNER JOIN @SalesOrderDetail_Temp_IMOLTP SalesOrderDetail_Temp_IMOLTP
ON SalesOrderHeader_Temp_IMOLTP.SalesOrderID = SalesOrderDetail_Temp_IMOLTP.SalesOrderID
INNER JOIN sales.SalesOrderDetail
ON SalesOrderDetail_Temp_IMOLTP.SalesOrderDetailID = SalesOrderDetail.SalesOrderDetailID
AND SalesOrderDetail_Temp_IMOLTP.SalesOrderID = SalesOrderDetail.SalesOrderID
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
AND SalesOrderHeader_Temp_IMOLTP.SalesPersonID = 277;
-- Perform a join between a disk table and return rows to SSMS
SELECT
	SalesOrderHeader_Temp_IMOLTP.SalesOrderID,
	SalesOrderDetail_Temp_IMOLTP.SalesOrderDetailID,
	SalesOrderDetail.OrderQty,
	SalesOrderDetail_Temp_IMOLTP.OrderQty
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
INNER JOIN @SalesOrderDetail_Temp_IMOLTP SalesOrderDetail_Temp_IMOLTP
ON SalesOrderHeader_Temp_IMOLTP.SalesOrderID = SalesOrderDetail_Temp_IMOLTP.SalesOrderID
INNER JOIN sales.SalesOrderDetail
ON SalesOrderDetail_Temp_IMOLTP.SalesOrderDetailID = SalesOrderDetail.SalesOrderDetailID
AND SalesOrderDetail_Temp_IMOLTP.SalesOrderID = SalesOrderDetail.SalesOrderID
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707
AND SalesOrderHeader_Temp_IMOLTP.SalesPersonID = 277;

-- Perform a join/select/seek against our data set
SELECT
	*
FROM @SalesOrderHeader_Temp_IMOLTP SalesOrderHeader_Temp_IMOLTP
INNER JOIN @SalesOrderDetail_Temp_IMOLTP SalesOrderDetail_Temp_IMOLTP
ON SalesOrderHeader_Temp_IMOLTP.SalesOrderID = SalesOrderDetail_Temp_IMOLTP.SalesOrderID 
WHERE SalesOrderHeader_Temp_IMOLTP.CustomerID = 29707;
GO
-- Reads for memory-optimized table examples: 2,826 (the reads needed to get the data from disk-based tables to join in)

------------------------------------------------------------------------------------------------------------------------------
-------------------------Natively Compiled Stored Procedures------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------

-- Create a standard disk-based stored procedure that collects data from Person.EmailAddress
CREATE PROCEDURE dbo.get_email_address_data_IMOLTP_Native
	(@BusinessEntityID INT = NULL)
WITH NATIVE_COMPILATION, SCHEMABINDING
AS
BEGIN ATOMIC WITH (TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = N'us_english') 
	IF @BusinessEntityID IS NULL
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM Person.EmailAddress_IMOLTP
	END
	ELSE
	BEGIN
		SELECT
			BusinessEntityID,
			EmailAddressID,
			EmailAddress
		FROM person.EmailAddress_IMOLTP
		WHERE BusinessEntityID = @BusinessEntityID
	END
END
GO

SET STATISTICS IO ON;
GO
PRINT 'Execution 1: Memory-optimized tables & classic stored procedure';
EXEC get_email_address_data_IMOLTP @BusinessEntityID = 12894
GO
PRINT 'Execution 2: Memory-optimized tables & natively-compiled stored procedure'; -- Note no parse/compile time!
EXEC get_email_address_data_IMOLTP_Native @BusinessEntityID = 12894
GO

-- See the full DLL file name and its location on disk.
SELECT
	LOADED_MODULES.name,
	LOADED_MODULES.description
FROM sys.dm_os_loaded_modules LOADED_MODULES
WHERE LOADED_MODULES.description = 'XTP Native DLL';

SELECT * FROM sys.databases WHERE databases.[name] = 'AdventureWorks2017'; -- Get Database ID for a referenced table
SELECT * FROM sys.objects WHERE objects.[name] = 'EmailAddress_IMOLTP'; -- Get Object ID for a referenced table

SELECT
	LOADED_MODULES.name,
	LOADED_MODULES.description
FROM sys.dm_os_loaded_modules LOADED_MODULES
WHERE LOADED_MODULES.name LIKE '%xtp[_]t[_]' + CAST(DB_ID() AS VARCHAR(10)) + '_' + CAST(OBJECT_ID('Person.EmailAddress_IMOLTP') AS VARCHAR(10)) + '%'
AND LOADED_MODULES.description = 'XTP Native DLL';

-- We can also get the proc text like this:
EXEC sp_helptext 'get_email_address_data_IMOLTP';
-- Or like this
SELECT
	*
FROM sys.sql_modules
INNER JOIN sys.objects
ON objects.object_id = sql_modules.object_id
WHERE objects.[name] = 'get_email_address_data_IMOLTP'

------------------------------------------------------------------------------------------------------------------------------
-------------------------Memory-Optimized TempDB Metadata---------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------

USE WideWorldImporters;
SET STATISTICS IO ON;
SET NOCOUNT ON;
GO
-- Check and see if Memory-Optimized TempDB Metadata is enabled:
SELECT SERVERPROPERTY('IsTempdbMetadataMemoryOptimized');


-- Create temporary table for demo purposes
CREATE TABLE #Dinner_Time
	(id INT NOT NULL PRIMARY KEY CLUSTERED,
	 food_name VARCHAR(15));
INSERT INTO #Dinner_Time
	(id, food_name)
VALUES
	(1, 'salad'),
	(2, 'soup'),
	(3, 'cheese plate'),
	(4, 'curry'),
	(5, 'tiramisu'),
	(6, 'breath mint');
-- Note objects on disk vs. in memory.  Look at IO!
SELECT
	*
FROM tempdb.sys.objects
WHERE is_ms_shipped = 0;
SELECT * FROM #Dinner_Time;
SELECT
	*
FROM tempdb.sys.columns
WHERE object_id=OBJECT_ID('tempdb.dbo.#Dinner_Time');
DROP TABLE #Dinner_Time;


-- Enable Memory-Optimized TempDB Metadata
ALTER SERVER CONFIGURATION SET MEMORY_OPTIMIZED TEMPDB_METADATA = ON;
-- Disconnect this session
-- Restart SQL Server Service


-- Reconnect this session
USE WideWorldImporters;
SET STATISTICS IO ON;
SET NOCOUNT ON;
GO
SELECT SERVERPROPERTY('IsTempdbMetadataMemoryOptimized');


CREATE TABLE #Dinner_Time
	(id INT NOT NULL PRIMARY KEY CLUSTERED,
	 food_name VARCHAR(15));
INSERT INTO #Dinner_Time
	(id, food_name)
VALUES
	(1, 'salad'),
	(2, 'soup'),
	(3, 'cheese plate'),
	(4, 'curry'),
	(5, 'tiramisu'),
	(6, 'breath mint');

-- Note IO
SELECT
	*
FROM tempdb.sys.objects
WHERE is_ms_shipped = 0;
SELECT * FROM #Dinner_Time;
SELECT
	*
FROM tempdb.sys.columns
WHERE object_id=OBJECT_ID('tempdb.dbo.#Dinner_Time');
DROP TABLE #Dinner_Time;


ALTER SERVER CONFIGURATION SET MEMORY_OPTIMIZED TEMPDB_METADATA = OFF;
-- Will take effect next time I restart services.

USE tempdb;
GO
-- Capacity Planning for TempDB and Memory-Optimized TempDB Metadata
-- Run these during various peak/of-peak usage times to gauge average/minimum/maximum usage

-- Determining the Current Amount of Free Space in tempdb
SELECT SUM(unallocated_extent_page_count) AS [free pages],
  (SUM(unallocated_extent_page_count)*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage;

-- Determining the Amount Space Used by the Version Store
SELECT ISNULL(SUM(version_store_reserved_page_count), 0) AS [version store pages used],
  ISNULL(SUM(version_store_reserved_page_count) * 1.0 / 128, 0) AS [version store space in MB]
FROM sys.dm_db_file_space_usage;

-- Determining the Amount of Space Used by Internal Objects
SELECT ISNULL(SUM(internal_object_reserved_page_count), 0) AS [internal object pages used],
  ISNULL(SUM(internal_object_reserved_page_count) * 1.0 / 128, 0) AS [internal object space in MB]
FROM sys.dm_db_file_space_usage;

-- Determining the Amount of Space Used by User Objects
SELECT ISNULL(SUM(user_object_reserved_page_count), 0) AS [user object pages used],
  ISNULL(SUM(user_object_reserved_page_count) * 1.0 / 128, 0) AS [user object space in MB]
FROM sys.dm_db_file_space_usage;

-- Details, if there is a need to dig into TempDB usage by connection, session, or application
-- Join to sys.sysprocesses and/or sys.dm_exec_sessions for more granular details about each spid.

-- Obtaining the space consumed by internal objects in all currently running tasks in each session
SELECT session_id,
  SUM(internal_objects_alloc_page_count) AS task_internal_objects_alloc_page_count,
  SUM(internal_objects_dealloc_page_count) AS task_internal_objects_dealloc_page_count
FROM sys.dm_db_task_space_usage
-- WHERE internal_objects_alloc_page_count > 0
GROUP BY session_id;

-- Obtaining the space consumed by internal objects in the current session for both running and completed tasks
SELECT R2.session_id,
  R1.internal_objects_alloc_page_count
  + SUM(R2.internal_objects_alloc_page_count) AS session_internal_objects_alloc_page_count,
  R1.internal_objects_dealloc_page_count
  + SUM(R2.internal_objects_dealloc_page_count) AS session_internal_objects_dealloc_page_count
FROM sys.dm_db_session_space_usage AS R1
INNER JOIN sys.dm_db_task_space_usage AS R2
ON R1.session_id = R2.session_id
-- WHERE internal_objects_alloc_page_count > 0
WHERE R2.session_id = @@SPID
GROUP BY R2.session_id, R1.internal_objects_alloc_page_count,
  R1.internal_objects_dealloc_page_count;


------------------------------------------------------------------------------------------------------------------------------
-------------------------Cleanup----------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------
USE AdventureWorks2017;
-- CLEANUP
DROP TYPE dbo.SalesOrderHeader_Temp_IMOLTP;
DROP TYPE dbo.SalesOrderDetail_Temp_IMOLTP;
GO

DROP PROCEDURE dbo.get_email_address_data;
DROP PROCEDURE dbo.get_email_address_data_IMOLTP;
DROP PROCEDURE dbo.get_email_address_data_IMOLTP_Native;

ALTER SERVER CONFIGURATION SET MEMORY_OPTIMIZED TEMPDB_METADATA = OFF;
GO