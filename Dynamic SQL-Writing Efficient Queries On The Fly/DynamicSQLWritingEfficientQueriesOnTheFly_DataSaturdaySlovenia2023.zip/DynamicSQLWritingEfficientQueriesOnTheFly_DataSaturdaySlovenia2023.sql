USE AdventureWorks2017;
SET STATISTICS IO ON;
GO

/***************************************************************************************
						WHAT DOES DYNAMIC SQL LOOK LIKE?
****************************************************************************************/

DECLARE @Sql_Command VARCHAR(MAX);
SELECT @Sql_Command = 'SELECT TOP 10 * FROM Person.Person';
EXEC (@Sql_Command);
GO

DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Table_Name VARCHAR(100);
SELECT @Table_Name = 'Person.Person';
SELECT @Sql_Command = 'SELECT TOP 10 * FROM ' + @Table_Name;
PRINT @Sql_Command;
EXEC (@Sql_Command);
GO

DECLARE @sql_command VARCHAR(MAX) = '';
SELECT @sql_command = @sql_command + '
	ALTER INDEX [' + indexes.name + '] ON [' + schemas.name + '].[' + objects.name + '] REBUILD; 
'
FROM sys.indexes
INNER JOIN sys.objects
ON objects.object_id = indexes.object_id
INNER JOIN sys.schemas
ON schemas.schema_id = objects.schema_id
WHERE indexes.type_desc = 'CLUSTERED'
AND objects.is_ms_shipped = 0;

PRINT @sql_command;
EXEC (@sql_command);
GO

/***************************************************************************************
						GOOD DYNAMIC SQL STYLE
****************************************************************************************/

DECLARE @Sql_Command VARCHAR(MAX) = ''; -- This will hold the final SQL to execute
DECLARE @First_Name VARCHAR(50) = 'Edward'; -- First name as entered in search box
DECLARE @Phone_Number_Type VARCHAR(10) = 'Cell'; -- Phone number type as entered in drop-down.  Optional.
SELECT @Sql_Command = -- Write dynamic SQL just like regular T-SQL.  Use the same spacing, indenting, etc...
'
SELECT
	Person.FirstName,
	Person.LastName,
	PersonPhone.PhoneNumber,
	PhoneNumberType.Name
FROM Person.Person
INNER JOIN Person.PersonPhone
ON Person.BusinessEntityID = PersonPhone.BusinessEntityID
INNER JOIN Person.PhoneNumberType
ON PersonPhone.PhoneNumberTypeID = PhoneNumberType.PhoneNumberTypeID
WHERE Person.FirstName = ''' + @First_Name + '''';

IF @Phone_Number_Type IS NOT NULL -- Only check phone # type if value is supplied!
BEGIN
	SELECT @Sql_Command = @Sql_Command +
	'
AND PhoneNumberType.Name = ''' + @Phone_Number_Type + ''';
	';
END

PRINT @Sql_Command;
EXEC (@Sql_Command);
GO


-- DONT DO THIS. PLEASE!
DECLARE @Sql_Command VARCHAR(MAX) = '', @First_Name VARCHAR(50) = 'Edward';
SELECT @Sql_Command =
'SELECT Person.FirstName, Person.LastName, PersonPhone.PhoneNumber, PhoneNumberType.Name FROM Person.Person INNER JOIN Person.PersonPhone ON Person.BusinessEntityID = PersonPhone.BusinessEntityID INNER JOIN Person.PhoneNumberType ON PersonPhone.PhoneNumberTypeID = PhoneNumberType.PhoneNumberTypeID WHERE Person.FirstName = ''' + @First_Name + '''';
EXEC (@Sql_Command);
GO


-- Beware mistakes in the text that will compile normally, but error at runtime:
DECLARE @Sql_Command VARCHAR(MAX);
SELECT @Sql_Command = 'SELLECT TOP 17 * FROM Person.Person;';
PRINT @Sql_Command;
EXEC (@Sql_Command);
GO

-- Also beware spacing mistakes.  It is easy to forget the space before or after a variable:
DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Table_Name VARCHAR(100);
SELECT @Table_Name = 'Person.Person';
SELECT @Sql_Command = 'SELECT TOP 10 * FROM' + @Table_Name;
PRINT @Sql_Command;
EXEC (@Sql_Command);
GO
/***************************************************************************************
						Efficient TSQL Generation
****************************************************************************************/
/*	String-building can be used to quickly & efficiently generate a list.  This is a review of some old-school
	approaches, and then the fun, dynamic way to accomplish the same tasks.
*/

/*	This is a common cursor-based iterative approach.  It's slow, inefficient, and not great for job security.
	Iteration forces us to read a table in every single loop.

	Total subtree cost: 2.006, 1021 logical reads!
*/
DECLARE @Next_ID INT;
DECLARE @ID_List VARCHAR(MAX) = '';

DECLARE ID_Cursor CURSOR FOR
	SELECT TOP 100
		Person.BusinessEntityID
	FROM Person.Person
	ORDER BY Person.LastName;
OPEN ID_Cursor;
FETCH NEXT FROM ID_Cursor INTO @Next_ID;
-- I want to generate a comma-separated-values list:
WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT @ID_List = @ID_List + CAST(@Next_ID AS VARCHAR(5)) + ',';
	FETCH NEXT FROM ID_Cursor INTO @Next_ID;
END

SELECT @ID_List = LEFT(@ID_List, LEN(@ID_List) - 1);
CLOSE ID_Cursor;
DEALLOCATE ID_Cursor;
SELECT @ID_List;
GO

/*	XML allows you to crunch row data from tables into strings.  While a common approach, XML is a CPU-intensive operation, as well as
	costlier in execution plan generation.  This method does reduce reads greatly as we only need to scan the table once, but query
	cost and CPU/memory needed to execute will still be somewhat high.

	XML should be reserved for applications where XML is necessary or the natural solution.

	Total subtree cost: 1.08051, 3 logical reads (far less reads, but still heavier on processing)
*/
DECLARE @ID_List VARCHAR(MAX) = '';

SELECT @ID_List =	STUFF((SELECT TOP 100 ',' + CAST(Person.BusinessEntityID AS VARCHAR(5))
				FROM Person.Person
				ORDER BY Person.LastName
				FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'), 1, 1, '');

SELECT @ID_List;
GO

/*	String-building can be used to generate a list from a table extremely quickly.  It reads the data source once,
	minimizing IO, and since there is no extra processing involved, CPU/memory use is tiny.

	Total subtree cost: 0.0038369, 3 logical reads (far less reads AND far less processing!)
*/
DECLARE @ID_List VARCHAR(MAX) = '';
SELECT TOP 100
	@ID_List = @ID_List + CAST(Person.BusinessEntityID AS VARCHAR(5)) + ','
FROM Person.Person
ORDER BY Person.LastName;

SELECT @ID_List = LEFT(@ID_List, LEN(@ID_List) - 1);
SELECT @ID_List;

-- Note that STRING_AGG (SQL Server 2017+) can be used for some string building. It is an aggregate
-- function, so it must be used with a GROUP BY or implicit aggregation.

/*	Lists can be created from multiple columns as well:	*/
DECLARE @My_Data VARCHAR(MAX) = ''
SELECT
	@My_Data = @My_Data + CAST(ContactType.ContactTypeID AS VARCHAR(50)) + ',' + ContactType.Name + ','
FROM person.ContactType;

SELECT @My_Data = LEFT(@My_Data, LEN(@My_Data) - 1);

SELECT @My_Data;
GO

/*
	List-building leads us into building TSQL out of table-components, allowing us to generate long/accurate scripts with very little
	overhead or maintenance.
*/
-- Rebuild every clustered index in a database:
DECLARE @sql_command VARCHAR(MAX) = '';
SELECT @sql_command = @sql_command + '
	ALTER INDEX [' + indexes.name + '] ON [' + schemas.name + '].[' + objects.name + '] REBUILD; 
'
FROM sys.indexes
INNER JOIN sys.objects
ON objects.object_id = indexes.object_id
INNER JOIN sys.schemas
ON schemas.schema_id = objects.schema_id
WHERE indexes.type_desc = 'CLUSTERED'
AND objects.is_ms_shipped = 0;

PRINT @sql_command;
EXEC (@sql_command);
GO
/***************************************************************************************
						sp_executesql
****************************************************************************************/
/*	While EXEC allows us to execute dynamic SQL command strings, it is limited in functionality and security.

	sp_executesql is a system stored procedure that is built solely to allow for the efficient execution of
	Dynamic SQL.  It improves security, allows for parameterization, and makes our syntax more readable.
*/

-- Here is our example from earlier:
DECLARE @Sql_Command VARCHAR(MAX) = ''; -- This will hold the final SQL to execute
DECLARE @First_Name VARCHAR(50) = 'Edward'; -- First name as entered in search box
DECLARE @Phone_Number_Type VARCHAR(10) = 'Cell'; -- Phone number type as entered in drop-down.  Optional.
SELECT @Sql_Command = 
'
SELECT
	Person.FirstName,
	Person.LastName,
	PersonPhone.PhoneNumber,
	PhoneNumberType.Name
FROM Person.Person
INNER JOIN Person.PersonPhone
ON Person.BusinessEntityID = PersonPhone.BusinessEntityID
INNER JOIN Person.PhoneNumberType
ON PersonPhone.PhoneNumberTypeID = PhoneNumberType.PhoneNumberTypeID
WHERE Person.FirstName = ''' + @First_Name + '''
';

IF @Phone_Number_Type IS NOT NULL -- Only check phone # type if value is supplied!
BEGIN
	SELECT @Sql_Command = @Sql_Command +
	'
	AND PhoneNumberType.Name = ''' + @Phone_Number_Type + '''
	';
END

PRINT @Sql_Command;
EXEC (@Sql_Command);
GO

-- Using sp_executesql, it would look like this:
DECLARE @Sql_Command NVARCHAR(MAX) = ''; -- This will hold the final SQL to execute
DECLARE @First_Name VARCHAR(50) = 'Edward'; -- First name as entered in search box
DECLARE @Phone_Number_Type VARCHAR(10) = 'Cell'; -- Phone number type as entered in drop-down.  Optional.
SELECT @Sql_Command = 
'
SELECT
	Person.FirstName,
	Person.LastName,
	PersonPhone.PhoneNumber,
	PhoneNumberType.Name
FROM Person.Person
INNER JOIN Person.PersonPhone
ON Person.BusinessEntityID = PersonPhone.BusinessEntityID
INNER JOIN Person.PhoneNumberType
ON PersonPhone.PhoneNumberTypeID = PhoneNumberType.PhoneNumberTypeID
WHERE Person.FirstName = @first_name
';

IF @Phone_Number_Type IS NOT NULL -- Only check phone # type if value is supplied!
BEGIN
	SELECT @Sql_Command = @Sql_Command +
	'
	AND PhoneNumberType.Name = @phone_number_type
	';
END

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command, N'@first_name NVARCHAR(50), @phone_number_type NVARCHAR(10)', @First_Name, @Phone_Number_Type;

-- Parameter list can also be stored in a scalar variable, to improve readability
DECLARE @Parameter_List NVARCHAR(MAX) = N'@first_name NVARCHAR(50), @phone_number_type NVARCHAR(10)';
EXEC sp_executesql @Sql_Command, @Parameter_List, @First_Name, @Phone_Number_Type;
GO
/***************************************************************************************
						SQL Injection
****************************************************************************************/
/*	These are brief demos indicating what SQL injection is, and how it can cause headaches for us if not considered/
*/

-- This simulates a very simple first name search of the Person.Person table:
DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Search_Criteria VARCHAR(1000); -- This comes from user input

SELECT @Sql_Command = 'SELECT * FROM Person.Person
WHERE FirstName = ''';
SELECT @search_criteria = 'Edward';
SELECT @Sql_Command = @Sql_Command + @Search_Criteria;
SELECT @Sql_Command = @Sql_Command + '''';
PRINT @Sql_Command;
EXEC (@Sql_Command);
GO

-- What if a user uses an apostrophe in their search terms?
DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Search_Criteria VARCHAR(1000); -- This comes from user input

SELECT @Sql_Command = 'SELECT * FROM Person.Person
WHERE FirstName = ''';
SELECT @search_criteria = 'O''Brien';
SELECT @Sql_Command = @Sql_Command + @Search_Criteria;
SELECT @Sql_Command = @Sql_Command + '''';
PRINT @Sql_Command;
EXEC (@Sql_Command); -- This generates a syntax error as Brien' is being read as SQL after the 2nd apostrophe
GO

-- What if a malicious user wants to exploit this?  They can end a string using apostrophes and then enter their own TSQL to execute!
DECLARE @Sql_Command VARCHAR(MAX);
DECLARE @Search_Criteria VARCHAR(1000); -- This comes from user input

SELECT @Sql_Command = 'SELECT * FROM Person.Person
WHERE FirstName = ''';
SELECT @search_criteria = ''' SELECT * FROM Person.Password; SELECT ''';
SELECT @Sql_Command = @Sql_Command + @Search_Criteria;
SELECT @Sql_Command = @Sql_Command + '''';
PRINT @Sql_Command;
EXEC (@Sql_Command); -- There go all our passwords :-\
GO

/*	The user can do whatever they want once they terminate the quotes, assuming they have permissions
	The SQL looks like this when executed!  It could have potentially dropped, updated, deleted, or otherwise
	 brutalized our database before we had any opportunity to stop them.
		SELECT * FROM Person.Person
		WHERE FirstName = '' SELECT * FROM Person.Password; SELECT ''
*/
GO

/*	There are many solutions to SQL injection, including layered security, sp_executesql, and input cleansing/validation.
	
	Here is one way to solve the mess presented above:
*/
IF EXISTS (SELECT * FROM sys.procedures WHERE procedures.name = 'Search_People')
BEGIN
	DROP PROCEDURE dbo.Search_People;
END
GO

CREATE PROCEDURE dbo.Search_People
	 (@Search_Criteria NVARCHAR(1000) = NULL) -- This comes from user input
AS
BEGIN
	DECLARE @Sql_Command NVARCHAR(MAX);
	SELECT @Sql_Command = 'SELECT * FROM Person.Person
	WHERE 1 = 1';
	IF @search_criteria IS NOT NULL
		SELECT @Sql_Command = @Sql_Command + '
	AND FirstName = @search_criteria';
	PRINT @Sql_Command;
	EXEC sp_executesql @Sql_Command, N'@search_criteria NVARCHAR(1000)', @search_criteria;
END
GO

-- This runs as usual:
EXEC search_people 'Edward';
-- One more example for the name with an apostrophe in it:
EXEC search_people 'O''Brien';
-- By parameterizing sp_executesql, we force this to search like any other text, even with the attempted attack:
EXEC search_people ''' SELECT * FROM Person.Password; SELECT ''';

DROP PROCEDURE search_people; -- Cleanup
GO

-- Another solution is to use QUOTENAME to ensure that the input is properly cleansed on the way in:
CREATE PROCEDURE dbo.Search_People
	 (@Search_Criteria NVARCHAR(1000) = NULL) -- This comes from user input
AS
BEGIN
	DECLARE @Sql_Command NVARCHAR(MAX); -- Must be NVARCHAR, as that is how sp_executesql is built
	SELECT @Sql_Command = 'SELECT * FROM Person.Person
	WHERE 1 = 1';

	IF @Search_Criteria IS NOT NULL
		SELECT @Sql_Command = @Sql_Command + '
	AND FirstName = ' + QUOTENAME(@Search_Criteria, '''');
	PRINT @Sql_Command;
	EXEC sp_executesql @Sql_Command;
END
GO

-- This runs as usual:
EXEC search_people 'Edward'
-- One more example for the name with an apostrophe in it:
EXEC search_people 'O''Brien'
-- By using QUOTENAME, we force the input text to be formatted correctly, regardless of the characters entered:
EXEC search_people ''' SELECT * FROM Person.Password; SELECT '''

DROP PROCEDURE search_people -- Cleanup
GO

/*	Ideally, We parameterize the stored procedure AND sp_executesql.  This guards against manipulation at both a local level and a proc call level.
*/
CREATE PROCEDURE dbo.Search_People
	 (@Search_Criteria NVARCHAR(1000) = NULL) -- This comes from user input
AS
BEGIN

	DECLARE @Sql_Command NVARCHAR(MAX); -- Must be NVARCHAR, as that is how sp_executesql is built
	DECLARE @parameter_list NVARCHAR(MAX) = '@Search_Criteria NVARCHAR(1000)';
	SELECT @Sql_Command = 'SELECT * FROM Person.Person
	WHERE 1 = 1';

	IF @Search_Criteria IS NOT NULL
		SELECT @Sql_Command = @Sql_Command + '
	AND FirstName = @Search_Criteria';
	PRINT @Sql_Command;
	EXEC sp_executesql @Sql_Command, @parameter_list, @Search_Criteria;
END
GO

-- This runs as usual:
EXEC search_people @Search_Criteria = 'Edward';
-- One more example for the name with an apostrophe in it:
EXEC search_people @Search_Criteria = 'O''Brien';
-- By using QUOTENAME, we force the input text to be formatted correctly, regardless of the characters entered:
EXEC search_people @Search_Criteria = ''' SELECT * FROM Person.Password; SELECT ''';

DROP PROCEDURE search_people -- Cleanup
GO

-- These are some ways to resolve dynamic SQL. There are many more out there! Depending on your data platform,
-- application, and code requirements, you may use this in conjunction with many other security measures.

/***************************************************************************************
						Saving Dynamic SQL Output
****************************************************************************************/
-- This example shows a dynamic query being built that selects some data from a table and outputs it directly
-- into a table variable for future use.  This example is trivial, but there are instances where there may be
-- no better way to select data from dynamic SQL.

DECLARE @SQL_Command NVARCHAR(MAX);

CREATE TABLE #output
(	PersonType NCHAR(2),
	Title NVARCHAR(8),
	FirstName NVARCHAR(50),
	LastName NVARCHAR(50),
	Suffix NVARCHAR(10));

DECLARE @search_term NVARCHAR(50) = 'Edward';
DECLARE @promotion BIT = 1;

SELECT @SQL_Command = '
	SELECT
		PersonType,
		Title,
		FirstName,
		LastName,
		Suffix
	FROM Person.Person
	WHERE FirstName = ' + QUOTENAME(@search_term, '''');
IF @promotion = 0
	SELECT @SQL_Command = @SQL_Command + '
	AND EmailPromotion = 0';
ELSE
	SELECT @SQL_Command = @SQL_Command + '
	AND EmailPromotion <> 0';
PRINT @SQL_Command;
INSERT INTO #output
(	PersonType,
	Title,
	FirstName,
	LastName,
	Suffix)
EXEC sp_executesql @SQL_Command;

SELECT
	*
FROM #output;

DROP TABLE #output;
GO

/*	This is an example of using an OUTPUT parameter.  When used, the value can be changed within dynamic SQL
	and passed back to the calling app.

	Normally, scalar variables created or altered within dynamic SQL are in a different scope from the calling proc
	and those changes will not carry through.  Consider parameters in dynamic SQL similarly to stored procedure parameters
	or parameters used when writing application code.
*/

IF EXISTS (SELECT * FROM sys.procedures WHERE procedures.name = 'Search_People')
BEGIN
	DROP PROCEDURE dbo.Search_People;
END
GO

CREATE PROCEDURE dbo.Search_People
	 (@Search_Criteria NVARCHAR(1000) = NULL) -- This comes from user input
AS
BEGIN
	DECLARE @Sql_Command NVARCHAR(MAX);
	DECLARE @Results_Found BIT = NULL;

	SELECT @Sql_Command = 'SELECT * FROM Person.Person
	WHERE 1 = 1';
	IF @search_criteria IS NOT NULL
		SELECT @Sql_Command = @Sql_Command + '
	AND FirstName = @search_criteria;
	
	IF @@ROWCOUNT > 0
	BEGIN
		SELECT @Results_Found = 1;
	END
	';
	PRINT @Sql_Command;

	SELECT @Results_Found;
	EXEC sp_executesql @Sql_Command, N'@search_criteria NVARCHAR(1000), @Results_Found BIT OUTPUT', @search_criteria, @Results_Found OUTPUT;
	SELECT @Results_Found;
END
GO

EXEC dbo.Search_People 'Edward'; -- Note that @Results_Found changes from NULL to 1.  If we remove the OUTPUT keyword, then it will remain NULL.
GO

DROP PROCEDURE dbo.Search_People;
/***************************************************************************************
						Dynamic Pivot
****************************************************************************************/
/*	By default, PIVOT requires a static list of values to be used as the column headers when we pivot row data into
	column data.  We can use dynamic SQL to allow for a flexible column header list.  The result can be extremely
	useful when data must be pivoted, but we do not know until runtime which values to pivot/aggregate on.	*/

-- Example: A query that calculates the quantity of each product by color, moving the colors to the column headers:
SELECT
	product_name,
	PIVOT_DATA.ReorderPoint,
	ISNULL(Black, 0) AS Black,
	ISNULL(Blue, 0) AS Blue,
	ISNULL(Grey, 0) AS Grey,
	ISNULL(Multi, 0) AS Multi,
	ISNULL(Red, 0) AS Red,
	ISNULL(Silver, 0) AS Silver,
	ISNULL([Silver/Black], 0) AS [Silver/Black],
	ISNULL(White, 0) AS White,
	ISNULL(Yellow, 0) AS Yellow
FROM
(	SELECT
		Product.Name AS product_name,
		Product.Color AS product_color,
		Product.ReorderPoint,
		ProductInventory.Quantity AS product_quantity
	FROM Production.Product
    LEFT JOIN Production.ProductInventory
    ON Product.ProductID = ProductInventory.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_quantity)
	FOR product_color IN ([Black], [Blue], [Grey], [Multi], [Red], [Silver], [Silver/Black], [White], [Yellow]  )
) PIVOT_DATA;

/*
	The color list MUST be provided in the PIVOT using explicit names.
	What if we want to pass in a table of colors and ONLY generate columns for those?

	Dynamic SQL allows us to provide a custom list of PIVOT articles:
*/

CREATE TABLE #Color_List
	(Color_Name VARCHAR(25)	NOT NULL PRIMARY KEY CLUSTERED);

INSERT INTO #Color_List
	(Color_Name)
VALUES ('Black'), ('Grey'), ('Silver/Black'), ('White');

DECLARE @Sql_Command NVARCHAR(MAX);
SELECT @Sql_Command = '
SELECT
	*
FROM
(	SELECT
		Product.Name AS product_name,
		Product.Color AS product_color,
		Product.ReorderPoint,
		ProductInventory.Quantity AS product_quantity
	FROM Production.Product
    LEFT JOIN Production.ProductInventory
    ON Product.ProductID = ProductInventory.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_quantity)
	FOR product_color IN (';

SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM #Color_List;

SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '	)
) PIVOT_DATA
'

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command;

DROP TABLE #Color_List;
GO

/*	Similarly, we can feed the distinct color list from the data table (or a dimension table) in order
	to cover the complete color list, even if it changes over time.
*/

CREATE TABLE #Color_List
	(Color_Name VARCHAR(25)	NOT NULL PRIMARY KEY CLUSTERED);

INSERT INTO #Color_List
	(Color_Name)
SELECT DISTINCT
	Product.Color
FROM Production.Product
WHERE Product.Color IS NOT NULL;

DECLARE @Sql_Command NVARCHAR(MAX);
-- Build the base SQL for the PIVOT.  This is exactly the same as before.
SELECT @Sql_Command = '
SELECT
	product_name,
	ReorderPoint,'

SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM #Color_List;

SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '
FROM
(	SELECT
		Product.Name AS product_name,
		Product.Color AS product_color,
		Product.ReorderPoint,
		ProductInventory.Quantity AS product_quantity
	FROM Production.Product
    LEFT JOIN Production.ProductInventory
    ON Product.ProductID = ProductInventory.ProductID
) PRODUCT_DATA
PIVOT
(	SUM(product_quantity)
	FOR product_color IN (';

-- Add in our list of colors from above.  Be sure to include brackets and commas to avoid syntax errors when
-- this is executed
SELECT
	@Sql_Command = @Sql_Command + '[' + Color_Name + '], '
FROM #Color_List;

-- Remove that comma at the end since there are no more values to add to the list.
SELECT @Sql_Command = SUBSTRING(@Sql_Command, 1, LEN(@Sql_Command) - 1);

SELECT @Sql_Command = @Sql_Command + '	)
) PIVOT_DATA
'

PRINT @Sql_Command;
EXEC sp_executesql @Sql_Command;

DROP TABLE #Color_List;


-- Final test: Let's add a few new colors to the Production.Product table and re-run our query from above:
UPDATE Production.Product
	SET Product.Color = 'Fuschia'
WHERE Product.ProductID = 325; -- Decal 1
UPDATE Production.Product
	SET Product.Color = 'Aquamarine'
WHERE Product.ProductID = 326; -- Decal 2

/* 
-- Cleanup:

UPDATE Production.Product
SET Product.Color = NULL
WHERE Product.ProductID = 325;
UPDATE Production.Product
SET Product.Color = NULL
WHERE Product.ProductID = 326;

*/

