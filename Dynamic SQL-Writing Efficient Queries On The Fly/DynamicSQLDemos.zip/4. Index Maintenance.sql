USE AdventureWorks2017;
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE procedures.name = 'index_maintenance_daily')
BEGIN
	DROP PROCEDURE dbo.index_maintenance_daily;
END
GO
-- In this proc, we create an exceptions list that can be used to skip indexes that don't need to be defragmented.
-- The list is created as a table in AdventureWorks2014, but could be in any database, or passed in as a table variable or CSV-style list.
IF NOT EXISTS (SELECT * FROM sys.tables WHERE tables.name = 'index_maintenance_exceptions')
BEGIN
	CREATE TABLE dbo.index_maintenance_exceptions
	(	DatabaseName SYSNAME NOT NULL,
		SchemaName SYSNAME NOT NULL,
		ObjectName SYSNAME NOT NULL,
		IndexName SYSNAME NOT NULL	)
END
GO

TRUNCATE TABLE dbo.index_maintenance_exceptions;

INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'Production', 'Product', 'AK_Product_ProductNumber';
INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'Production', 'Product', 'AK_Product_rowguid';
INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'Sales', 'Store', 'AK_Store_rowguid';
INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'Purchasing', 'ProductVendor', 'IX_ProductVendor_UnitMeasureCode';
INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'dbo', 'DatabaseLog', 'PK_DatabaseLog_DatabaseLogID';
INSERT INTO dbo.index_maintenance_exceptions
	(DatabaseName, SchemaName, ObjectName, IndexName)
SELECT 'AdventureWorks2017', 'HumanResources', 'Employee', 'AK_Employee_LoginID';
GO

CREATE PROCEDURE dbo.index_maintenance_daily
	@database_name NVARCHAR(MAX) = NULL,
	@reorganization_percentage TINYINT = 10,
	@rebuild_percentage TINYINT = 35,
	@object_name NVARCHAR(MAX) = NULL,
	@log_space_free_required_gb INT = 10,
	@Allowable_Start_Time TIME = '23:00:00',
	@Allowable_End_Time TIME = '07:00:00',
	@Maximum_Duration_Minutes SMALLINT = 360,
	@Check_Exceptions BIT = 0

AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @job_start_time DATETIME = CURRENT_TIMESTAMP;

	DECLARE @sql_command NVARCHAR(MAX) = '';
	DECLARE @parameter_list NVARCHAR(MAX) = '@reorganization_percentage TINYINT, @rebuild_percentage TINYINT'
	DECLARE @database_list TABLE
		(database_name NVARCHAR(MAX) NOT NULL);
	
	INSERT INTO @database_list
		(database_name)
	SELECT
		name
	FROM sys.databases
	WHERE databases.name NOT IN ('msdb', 'master', 'TempDB', 'model');

	IF @database_name IS NOT NULL
	BEGIN
		DELETE FROM @database_list
		WHERE database_name <> @database_name;
	END

	CREATE TABLE #index_maintenance
	(	database_name NVARCHAR(MAX) NOT NULL,
		schema_name NVARCHAR(MAX) NOT NULL,
		object_name NVARCHAR(MAX) NOT NULL,
		index_name NVARCHAR(MAX) NOT NULL,
		index_type_desc NVARCHAR(MAX) NOT NULL,
		avg_fragmentation_in_percent FLOAT NOT NULL,
		index_operation NVARCHAR(MAX) NOT NULL,
		size_in_GB DECIMAL(24,2) NOT NULL);

	SELECT @sql_command = @sql_command + '
	USE [' + database_name + ']

	INSERT INTO #index_maintenance
		(database_name, schema_name, object_name, index_name, index_type_desc, avg_fragmentation_in_percent, index_operation,size_in_GB)
	SELECT
		CAST(SD.name AS NVARCHAR(MAX)) AS database_name,
		CAST(SS.name AS NVARCHAR(MAX)) AS schema_name,
		CAST(SO.name AS NVARCHAR(MAX)) AS object_name,
		CAST(SI.name AS NVARCHAR(MAX)) AS index_name,
		IPS.index_type_desc,
		IPS.avg_fragmentation_in_percent, -- Be sure to filter as much as possible...this can return a lot of data if you dont filter by database and table.
		CAST(CASE
			WHEN IPS.avg_fragmentation_in_percent >= @rebuild_percentage THEN ''REBUILD''
			WHEN IPS.avg_fragmentation_in_percent >= @reorganization_percentage THEN ''REORGANIZE''
		END AS NVARCHAR(MAX)) AS index_operation,
		CAST(page_count AS DECIMAL(24,2)) * 8.0000 / 1024.0000 / CAST(1024 AS DECIMAL(24,2)) AS size_in_GB
	FROM sys.dm_db_index_physical_stats(NULL, NULL, NULL, NULL , NULL) IPS
	INNER JOIN sys.databases SD
	ON SD.database_id = IPS.database_id
	INNER JOIN sys.indexes SI
	ON SI.index_id = IPS.index_id
	INNER JOIN sys.objects SO
	ON SO.object_id = SI.object_id
	AND IPS.object_id = SO.object_id
	INNER JOIN sys.schemas SS
	ON SS.schema_id = SO.schema_id
	WHERE alloc_unit_type_desc = ''IN_ROW_DATA''
	AND index_level = 0
	AND SD.name = ''' + database_name + '''
	AND IPS.avg_fragmentation_in_percent >= @reorganization_percentage
	AND SI.name IS NOT NULL -- Only review index, not heap data.
	AND SO.is_ms_shipped = 0 -- Do not perform maintenance on system objects' +
	CASE WHEN @object_name IS NOT NULL THEN '
	AND SO.name = ''' + @object_name + ''''
	ELSE '' END + '
	ORDER BY SO.name ASC;'
	FROM @database_list
	WHERE database_name IN (SELECT name FROM sys.databases);

	EXEC sp_executesql @sql_command, @parameter_list, @reorganization_percentage, @rebuild_percentage;

	IF EXISTS (SELECT * FROM dbo.index_maintenance_exceptions)
	AND @Check_Exceptions = 1
	BEGIN
		DELETE INDEX_MAINTENANCE
		FROM #index_maintenance INDEX_MAINTENANCE
		INNER JOIN dbo.index_maintenance_exceptions
		ON INDEX_MAINTENANCE.database_name = index_maintenance_exceptions.DatabaseName
		AND INDEX_MAINTENANCE.schema_name = index_maintenance_exceptions.SchemaName
		AND INDEX_MAINTENANCE.object_name = index_maintenance_exceptions.ObjectName
		AND INDEX_MAINTENANCE.index_name = index_maintenance_exceptions.IndexName;
	END

	SELECT @sql_command = 'DECLARE @log_drive_space_free_gb INT;
		DECLARE @error_message VARCHAR(MAX);
		DECLARE @current_datetime DATETIME;
		DECLARE @current_time TIME;';
	SELECT @sql_command = @sql_command +
	'	USE [' + database_name + '];

		SELECT
			@log_drive_space_free_gb = CAST(CAST(available_bytes AS DECIMAL) / (1024 * 1024 * 1024) AS BIGINT)
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id)
		WHERE f.database_id = DB_ID()
		AND f.type_desc = ''LOG'';

		SELECT @error_message = ''Not enough space available to process maintenance on ' + index_name + ' while executing the nightly index maintenance job.  '' + CAST(@log_drive_space_free_gb AS VARCHAR(MAX)) + ''GB are currently free.''

		IF @log_drive_space_free_gb - ' + CAST(size_in_GB AS VARCHAR(MAX)) + ' < @log_space_free_required_gb
		BEGIN
			RAISERROR(@error_message, 16, 1);
			RETURN;
		END

		SELECT @current_datetime = CURRENT_TIMESTAMP;
		SELECT @current_time = CAST(CURRENT_TIMESTAMP AS TIME);

		IF DATEDIFF(MINUTE, @job_start_time, @current_datetime) >= @Maximum_Duration_Minutes
		BEGIN
			SELECT @error_message = ''This job has exceeded the maximum runtime allowed ('' + CAST(@Maximum_Duration_Minutes AS NVARCHAR(MAX)) + '' minutes).  Start time: '' +
			CONVERT(NVARCHAR(10), @job_start_time, 101) + '' '' + CONVERT(VARCHAR(12), @job_start_time, 114) + '' Current Time: '' +
			CONVERT(NVARCHAR(10), @current_datetime, 101) + '' '' + CONVERT(VARCHAR(12), @current_datetime, 114);

			RAISERROR(@error_message, 16, 1);
			RETURN
		END

		IF @current_time NOT BETWEEN @Allowable_Start_Time AND @Allowable_End_Time
		BEGIN
			SELECT @error_message = ''This job is running outside of the allotted maintenance period ('' + CAST(@Allowable_Start_Time AS NVARCHAR(MAX)) + '' - '' + CAST(@Allowable_End_Time AS NVARCHAR(MAX)) + '').  Current time: '' + CAST(@current_time AS VARCHAR(MAX));
			RAISERROR(@error_message, 16, 1);
			RETURN
		END

		ALTER INDEX [' + index_name + '] ON [' + schema_name + '].[' + object_name + ']
		' + index_operation + ';'
	FROM #index_maintenance;

	SELECT @parameter_list = '@log_space_free_required_gb INT, @job_start_time DATETIME, @Maximum_Duration_Minutes SMALLINT, @Allowable_Start_Time TIME, @Allowable_End_Time TIME'

	SELECT * FROM #index_maintenance
	ORDER BY avg_fragmentation_in_percent;

	EXEC sp_executesql @sql_command, @parameter_list, @log_space_free_required_gb, @job_start_time, @Maximum_Duration_Minutes, @Allowable_Start_Time, @Allowable_End_Time;

	DROP TABLE #index_maintenance;
END
GO

EXEC dbo.index_maintenance_daily @Database_Name = 'AdventureWorks2017', @reorganization_percentage = 15, @rebuild_percentage = 30,
	 @Allowable_Start_Time = '00:00:00', @Allowable_End_Time = '23:59:59';
GO

EXEC dbo.index_maintenance_daily @Database_Name = 'AdventureWorks2017', @reorganization_percentage = 15, @rebuild_percentage = 30,
	 @Allowable_Start_Time = '00:00:00', @Allowable_End_Time = '23:59:59', @Check_Exceptions = 1;
GO

EXEC dbo.index_maintenance_daily @Database_Name = 'AdventureWorks2017', @reorganization_percentage = 15, @rebuild_percentage = 30,
	 @Allowable_Start_Time = '22:00:00', @Allowable_End_Time = '5:00:00', @Check_Exceptions = 1;
GO
--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------