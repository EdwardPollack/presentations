/*
	This script will create schema that allows for the automatic creation of dimension tables based on some metadata that we create.
*/
USE AdventureWorks2017;
GO
/*	Create metadata table to manage all dimensions that we will track.  This allows us to easily add and remove them without the
	need to alter any schema	*/
IF NOT EXISTS (SELECT * FROM sys.tables WHERE tables.name = 'Dimension_List')
BEGIN
	CREATE TABLE dbo.Dimension_List
	(	Dimension_ID SMALLINT NOT NULL IDENTITY(1,1) PRIMARY KEY CLUSTERED, -- Unique PK ID
		Target_Dimension_Table_Name VARCHAR(50) NOT NULL, -- The name of the dimension table we will create
		Source_Fact_Table_Name VARCHAR(128) NOT NULL, -- Source table for dimension data
		Source_Fact_Column_Name VARCHAR(50) NOT NULL -- The name of the source column we will read from
	);
END
GO
TRUNCATE TABLE dbo.Dimension_List;
GO
-- Populate dimension metadata table with list of dimensions, which can be easily edited later
INSERT INTO dbo.Dimension_List
	(Target_Dimension_Table_Name, Source_Fact_Table_Name, Source_Fact_Column_Name)
VALUES
	('Dim_Object', 'DatabaseLog', 'Object'),
	('Dim_Schema', 'DatabaseLog', 'Schema'),
	('Dim_Event', 'DatabaseLog', 'Event'),
	('Dim_Database_User', 'DatabaseLog', 'DatabaseUser');
GO

-- Create stored procedure to populate all dim tables for fact_prr_reporting and fact_im_reporting
IF EXISTS (SELECT * FROM sys.procedures WHERE procedures.name = 'Populate_Report_Dimension_Tables')
BEGIN
	DROP PROCEDURE dbo.Populate_Report_Dimension_Tables;
END
GO

CREATE PROCEDURE dbo.Populate_Report_Dimension_Tables
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Sql_Command NVARCHAR(MAX) = '';
	-------------------------------------------------------------------------
	------------PRR & IM Dimensions, non-bit columns-------------------------
	-------------------------------------------------------------------------
	SELECT @Sql_Command = @Sql_Command + '
		USE Adventureworks2017;

		IF NOT EXISTS (SELECT * FROM sys.tables WHERE tables.name = ''' + Dimension_List.Target_Dimension_Table_Name + ''')
		BEGIN
			CREATE TABLE dbo.[' + Dimension_List.Target_Dimension_Table_Name + ']
			(	[' + Dimension_List.Target_Dimension_Table_Name + '_Id] INT NOT NULL IDENTITY(1,1) CONSTRAINT [PK_' + Dimension_List.Target_Dimension_Table_Name + '] PRIMARY KEY CLUSTERED,
				[' + Dimension_List.Source_Fact_Column_Name + '] VARCHAR(' + CAST(columns.max_length AS VARCHAR(MAX))+ ') NOT NULL
			);
		END
		ELSE
		BEGIN
			TRUNCATE TABLE dbo.[' + Dimension_List.Target_Dimension_Table_Name + '];
		END

		INSERT INTO dbo.[' + Dimension_List.Target_Dimension_Table_Name + ']
			([' + Dimension_List.Source_Fact_Column_Name + '])
		SELECT DISTINCT
			[' + Dimension_List.Source_Fact_Table_Name + '].[' + Dimension_List.Source_Fact_Column_Name + ']
		FROM [dbo].[' + Dimension_List.Source_Fact_Table_Name + ']
		WHERE [' + Dimension_List.Source_Fact_Table_Name + '].[' + Dimension_List.Source_Fact_Column_Name + '] IS NOT NULL;
	'
	FROM dbo.Dimension_List
	INNER JOIN sys.tables
	ON tables.name = Dimension_List.Source_Fact_Table_Name
	INNER JOIN sys.columns
	ON tables.object_id = columns.object_id
	AND columns.name COLLATE database_default = Dimension_List.Source_Fact_Column_Name
	INNER JOIN sys.types
	ON columns.user_type_id = types.user_type_id

	EXEC sp_executesql @Sql_Command;
END
GO

-- Run dimension table initial population
EXEC dbo.Populate_Report_Dimension_Tables;
GO

SELECT * FROM dbo.Dim_Object;
SELECT * FROM dbo.Dim_Schema;
SELECT * FROM dbo.Dim_Event;
SELECT * FROM dbo.Dim_Database_User;
GO

/*	-- Cleanup:
	DROP TABLE dbo.Dimension_List;
	DROP PROCEDURE dbo.Populate_Report_Dimension_Tables;
	DROP TABLE dbo.Dim_Object;
	DROP TABLE dbo.Dim_Schema;
	DROP TABLE dbo.Dim_Event;
	DROP TABLE dbo.Dim_Database_User;
*/