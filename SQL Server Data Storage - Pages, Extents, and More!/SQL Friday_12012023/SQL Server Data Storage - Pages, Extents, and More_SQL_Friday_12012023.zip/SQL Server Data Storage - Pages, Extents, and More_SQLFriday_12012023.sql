USE WideWorldImporters;
GO

/*********************************************************************************************
							Viewing Storage Information
*********************************************************************************************/
/*	dm_db_index_physical_stats provides:
		1 row per b-tree level for a b-tree index per partition.
		1 row per IN_ROW_DATA allocation unit per partition.
		1 row per LOB_DATA allocation unit per partition
		1 row per ROW_OVERFLOW_DATA allocation unit per partition	*/

SELECT
	tables.name AS TableName,
	indexes.name AS IndexName,
	dm_db_index_physical_stats.partition_number,
	dm_db_index_physical_stats.index_type_desc,
	dm_db_index_physical_stats.alloc_unit_type_desc,
	dm_db_index_physical_stats.index_depth,
	dm_db_index_physical_stats.index_level,
	dm_db_index_physical_stats.avg_fragmentation_in_percent,
	dm_db_index_physical_stats.fragment_count,
	dm_db_index_physical_stats.avg_fragment_size_in_pages,
	dm_db_index_physical_stats.page_count,
	dm_db_index_physical_stats.avg_page_space_used_in_percent,
	dm_db_index_physical_stats.record_count,
	dm_db_index_physical_stats.avg_record_size_in_bytes
FROM sys.dm_db_index_physical_stats (DB_ID('WideWorldImporters'), OBJECT_ID(N'Sales.Orders'), NULL, NULL , 'DETAILED')
INNER JOIN sys.indexes
ON indexes.index_id = dm_db_index_physical_stats.index_id
AND indexes.object_id = dm_db_index_physical_stats.object_id
INNER JOIN sys.tables
ON tables.object_id = indexes.object_id;

/*********************************************************************************************
							View Excessive Page Details
*********************************************************************************************/

SELECT * FROM sys.database_files; -- Can be added into the queries below.

-- sys.dm_db_page_info is documented and very useful for troubleshooting complex/unusual challenges.
-- Can replace DBCC PAGE for many use-cases - which is good because DBCC PAGE is undocumented.
-- Also very useful as a learning tool.

SELECT
	database_files.[type_desc] AS DatabaseFileType,
	database_files.[name] AS DatabaseFileName,
	database_files.physical_name,
	database_files.state_desc AS DatabaseFileState,
	database_files.size AS DatabaseFileSize,
	databases.[name] AS DatabaseName,
	objects.[name] AS ObjectName,
	indexes.[name] AS IndexName,
	dm_db_page_info.*
FROM sys.dm_db_page_info (DB_ID(DB_NAME()), 1, 100, DEFAULT)
INNER JOIN sys.database_files
ON database_files.file_id = dm_db_page_info.file_id
INNER JOIN sys.databases
ON databases.database_id = dm_db_page_info.database_id
LEFT JOIN sys.objects
ON objects.object_id = dm_db_page_info.object_id
LEFT JOIN sys.indexes
ON indexes.index_id = dm_db_page_info.index_id
AND indexes.object_id = dm_db_page_info.object_id;

/*********************************************************************************************
							Allocation Unit Details
*********************************************************************************************/

-- Allocation info per object and allocation type
SELECT tables.object_id AS ObjectID,
       OBJECT_NAME(tables.object_id) AS ObjectName,
       SUM(allocation_units.total_pages) * 8 AS Total_Reserved_kb,
       SUM(allocation_units.used_pages) * 8 AS Used_Space_kb,
       allocation_units.type_desc AS TypeDesc,
       MAX(partitions.rows) AS RowsCount
FROM sys.allocation_units
INNER JOIN sys.partitions
ON allocation_units.container_id = partitions.hobt_id
INNER JOIN sys.tables
ON partitions.object_id = tables.object_id
GROUP BY tables.object_id, OBJECT_NAME(tables.object_id), allocation_units.type_desc
ORDER BY Used_Space_kb DESC, ObjectName;

-- Excessive detail:
SELECT * FROM sys.allocation_units

-- Even more excessive detail. Also, this is an internal/minimally documented view and can change without notice.
SELECT * FROM sys.system_internals_allocation_units

-- Using allocation_units
SELECT
	objects.name AS TableName,
	indexes.[name] AS IndexName,
	partitions.partition_number,
	allocation_units.[type_desc] AS AllocationUnitType,
	allocation_units.total_pages,
	allocation_units.*
FROM sys.objects
INNER JOIN sys.partitions
ON objects.object_id = partitions.object_id
INNER JOIN sys.allocation_units
ON allocation_units.container_id = partitions.hobt_id
INNER JOIN sys.indexes
ON indexes.index_id = partitions.index_id
AND indexes.object_id = partitions.object_id
WHERE objects.[name] = 'Orders'

-- Using system_internals_allocation_units
SELECT
	objects.name AS TableName,
	indexes.[name] AS IndexName,
	partitions.partition_number,
	system_internals_allocation_units.[type_desc] AS AllocationUnitType,
	system_internals_allocation_units.total_pages,
	system_internals_allocation_units.*
FROM sys.objects
INNER JOIN sys.partitions
ON objects.object_id = partitions.object_id
INNER JOIN sys.system_internals_allocation_units
ON system_internals_allocation_units.container_id = partitions.hobt_id
INNER JOIN sys.indexes
ON indexes.index_id = partitions.index_id
AND indexes.object_id = partitions.object_id
WHERE objects.[name] = 'Orders';

/*********************************************************************************************
							Yes, We Can View Memory-Optimized Objects, Too
*********************************************************************************************/

-- This is provided for demo purposes, and can be helpful for understanding the space used by
-- different memory-optimized objects, as well as how they are stored. NULL-filled rows are system objects.
SELECT
	objects.[name] AS ObjectName,
	indexes.[name] AS IndexName,
	memory_optimized_tables_internal_attributes.type_desc,
	dm_db_xtp_memory_consumers.*,
	dm_db_xtp_table_memory_stats.*
FROM sys.dm_db_xtp_memory_consumers -- Allocated memory for memory-optimized objects (even if zero bytes thus far)
LEFT JOIN sys.objects -- Object metadata
ON objects.object_id = dm_db_xtp_memory_consumers.object_id
LEFT JOIN sys.indexes -- Index metadata
ON indexes.index_id = dm_db_xtp_memory_consumers.index_id
AND indexes.object_id = dm_db_xtp_memory_consumers.object_id
LEFT JOIN sys.dm_db_xtp_table_memory_stats -- Details on current index/space usage
ON dm_db_xtp_table_memory_stats.object_id = dm_db_xtp_memory_consumers.object_id
LEFT JOIN sys.memory_optimized_tables_internal_attributes -- Memory-optimized object type
ON memory_optimized_tables_internal_attributes.xtp_object_id = dm_db_xtp_memory_consumers.xtp_object_id

/*********************************************************************************************
							
*********************************************************************************************/