USE WideWorldImporters;
GO

/**************************************************************************************
*****************************Compatibility Level Notes*********************************
***************************************************************************************/

ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 170; -- SQL Server 2025

-- PRODUCT is SQL Server 2025+ syntax
SELECT
	PRODUCT(1 + TaxRate * 0.01)
FROM Sales.OrderLines
WHERE OrderID = 46;

-- Works in older compatibility levels
ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 140; -- SQL Server 2017

SELECT
	PRODUCT(1 + TaxRate * 0.01)
FROM Sales.OrderLines
WHERE OrderID = 46

ALTER DATABASE WideWorldImporters SET COMPATIBILITY_LEVEL = 170; -- SQL Server 2025
GO
-- ***NOT ALL FEATURES/SYNTAX WORK ACROSS ALL COMPATIBILITY LEVELS, BUT MOST DO***
/**************************************************************************************
**************************************PRODUCT******************************************
***************************************************************************************/

CREATE TABLE dbo.BankBalance
(	RowId INT NOT NULL IDENTITY(1,1) CONSTRAINT PK_BankBalance PRIMARY KEY CLUSTERED,
	StartDate DATE NOT NULL,
	EndDate DATE NOT NULL,
	StartBalance DECIMAL(18,2) NOT NULL,
	EndBalance DECIMAL(18,2) NOT NULL,
	AnnualInterestRate DECIMAL(7,4) NOT NULL);
-- Adds some basic bank balance data including annualized interest rate per month
INSERT INTO dbo.BankBalance
	(StartDate, EndDate, StartBalance, EndBalance, AnnualInterestRate)
VALUES
	('1/1/2024', '1/31/2024', 100.00, 100.44, 0.0523),
	('2/1/2024', '2/29/2024', 100.44, 100.86, 0.0501),
	('3/1/2024', '3/31/2024', 100.86, 101.27, 0.0490),
	('4/1/2024', '4/30/2024', 101.27, 101.66, 0.0463),
	('5/1/2024', '5/31/2024', 101.66, 102.02, 0.0424),
	('6/1/2024', '6/30/2024', 102.02, 102.38, 0.0426),
	('7/1/2024', '7/31/2024', 102.38, 102.74, 0.0407),
	('8/1/2024', '8/31/2024', 102.74, 103.09, 0.0395),
	('9/1/2024', '9/30/2024', 103.09, 103.43, 0.0382),
	('10/1/2024', '10/31/2024', 103.43, 103.76, 0.0381),
	('11/1/2024', '11/30/2024', 103.76, 104.08, 0.0374),
	('12/1/2024', '12/31/2024', 104.08, 104.37, 0.0329),
	('1/1/2025', '1/31/2025', 104.37, 104.63, 0.0300),
	('2/1/2025', '2/28/2025', 104.63, 104.89, 0.0299),
	('3/1/2025', '3/31/2025', 104.89, 105.14, 0.0283);

SELECT * FROM dbo.BankBalance;

-- How do we calculate interest prior to SQL Server 2025?
-- The iterative approach
DECLARE @CurrentDate DATE = '1/1/2024';
DECLARE @InterestRate DECIMAL(7,4) = 1;
WHILE @CurrentDate <= '12/31/2024'
BEGIN
	SELECT
		@InterestRate = @InterestRate * (1 + AnnualInterestRate / 12.0000)
	FROM dbo.BankBalance
	WHERE StartDate = @CurrentDate;

	SELECT @CurrentDate = DATEADD(MONTH, 1, @CurrentDate);
END
SELECT @InterestRate AS AnnualInterestRate2024;

-- Two set-based approaches
SELECT
	POWER(10.0000, SUM(LOG10(1 + AnnualInterestRate / 12.0000))) AS AnnualInterestRate2024
FROM dbo.BankBalance
WHERE StartDate >= '1/1/2024'
AND StartDate <= '12/1/2024';

SELECT
	EXP(SUM(LOG(1 + AnnualInterestRate / 12.0000))) AS AnnualInterestRate2024
FROM dbo.BankBalance
WHERE StartDate >= '1/1/2024'
AND StartDate <= '12/1/2024';

-- Using PRODUCT in SQL Server 2025
SELECT
	PRODUCT(1 + AnnualInterestRate / 12.0000) AS AnnualInterestRate2024
FROM dbo.BankBalance
WHERE StartDate >= '1/1/2024'
AND StartDate <= '12/1/2024';

-- PRODUCT as a window function:
SELECT
	StartDate,
	DATEPART(YEAR, StartDate) AS CurrentYear,
	AnnualInterestRate,
	PRODUCT(1 + AnnualInterestRate / 12.0000)
		OVER (PARTITION BY DATEPART(YEAR, StartDate) ORDER BY StartDate
		ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS RunningAnnualTotal
FROM dbo.BankBalance
ORDER BY StartDate;

DROP TABLE dbo.BankBalance;

/**************************************************************************************
**************************************REGEX********************************************
***************************************************************************************/
USE WideWorldImportersDW;
/*	REGEXP_LIKE: Returns a 1 if a Regex pattern is found within a string.
	Otherwise, returns 0.
*/
SELECT 
	* -- Finds any string ending in "NY)"
FROM Dimension.Customer
WHERE REGEXP_LIKE(Customer.Customer, ' NY[)]');

SELECT
	* -- Finds strings starting (^) in capital A and ending ($) in lowercase a
FROM Dimension.Customer
WHERE REGEXP_LIKE(Customer.[Primary Contact], '^A.*a$');

SELECT
	* -- Finds strings containing the letter "s" twice consecutively
FROM Dimension.Customer
WHERE REGEXP_LIKE(Customer.Customer, '[sS]{2,}');

/*	REGEXP_COUNT: Returns the number of times that a Regex pattern is found
	within a string.
*/
-- How many times in a string are there consecutive letter "s"?
SELECT
	[City Key],
	City,
	[State Province],
	REGEXP_COUNT(City.City, '[sS]{2,}') AS SequenceCount
FROM Dimension.City
ORDER BY REGEXP_COUNT(City.City, '[sS]{2,}') DESC;
-- Added parameter specifies what character to begin at:
SELECT
	[City Key],
	City,
	[State Province],
	REGEXP_COUNT(City.City, '[sS]{2,}', 6) AS SequenceCount
FROM Dimension.City
ORDER BY REGEXP_COUNT(City.City, '[sS]{2,}', 6) DESC;

SELECT
	* -- All cities starting with "New" followed immediately by a space "\s"
FROM Dimension.City
WHERE REGEXP_COUNT(City.City, '^New\s') > 0;
/*	REGEXP_INSTR: Finds the start/end position within a string for a given Regex expression.
*/
SELECT -- Finds all strings with "New" in them and returns its start location
	City.City,
	City.[State Province],
	REGEXP_INSTR(City.City, 'New') AS StringLocation
FROM Dimension.City
WHERE REGEXP_INSTR(City.City, 'New') > 0

SELECT -- Added parameter specifies what character to begin searching at.
	City.City,
	City.[State Province],
	REGEXP_INSTR(City.City, 'New', 2) AS StringLocation
FROM Dimension.City
WHERE REGEXP_INSTR(City.City, 'New', 2) > 0

SELECT -- The third parameter specifies which occurrence of the expression to locate.
	City.City,
	City.[State Province],
	REGEXP_INSTR(City.City, 'New', 1, 2) AS StringLocation
FROM Dimension.City
WHERE REGEXP_INSTR(City.City, 'New', 1, 2) > 0

SELECT -- Final parameter specifies whether the starting (0) or ending position (1) should be returned
	City.City,
	City.[State Province],
	REGEXP_INSTR(City.City, 'New', 1, 2, 1) AS StringLocation
FROM Dimension.City
WHERE REGEXP_INSTR(City.City, 'New', 1, 2, 1) > 0

SELECT -- We can get silly here, too:
	City.City,
	City.[State Province],
	REGEXP_INSTR(City.City, ' N.*?w', 1, 1, 0, 'i') AS StringLocation
FROM Dimension.City
WHERE REGEXP_INSTR(City.City, ' N.*?w', 1, 1, 0, 'i') > 0
/*	Return the start position in any city where the second (or later) word starts with "N"
	and is followed by a "w" later in the string.
	The "i" flag at the end makes the regular expression case-insensitive,
	which can be a handy flag for databases that use case-insensitive collations. */

/*	REGEXP_REPLACE: Works like REPLACE(), but using Regex expressions instead of string literals
*/
-- Replaces "New" with "Old". Just for fun :-)
SELECT
	City.City,
	City.[State Province],
	REGEXP_REPLACE(City.City, 'New', 'Old') AS OldCityName
FROM Dimension.City
WHERE REGEXP_COUNT(City.City, 'New') > 0;

-- Starting at character 5, this replaces "New" or "Old" with "Mid". Case-sensitive by default.
SELECT
	City.City,
	City.[State Province],
	REGEXP_REPLACE(City.City, 'New|Old', 'Mid', 5) AS MidCityName
FROM Dimension.City
WHERE REGEXP_COUNT(City.City, 'New|Old', 5) > 0;

/* Added parameter tells the function to only return results for the nth occurrence.
   In this case, it looks only for the 2nd occurrence, instead of the first	*/
SELECT
	City.City,
	City.[State Province],
	REGEXP_REPLACE(City.City, 'New|Old', 'Mid', 1, 2, 'i') AS MidCityName
FROM Dimension.City
WHERE REGEXP_REPLACE(City.City, 'New|Old', 'Mid', 1, 2, 'i') <> City.City;

/*	REGEXP_SUBSTR: Finds a Regex pattern and returns the substring that matches it.
*/
-- This returns the contents of parenthesis. If results are not found, NULL is returned.
SELECT
	Customer.[Customer Key],
	Customer.Customer,
	REGEXP_SUBSTR(Customer.Customer, '\(([^)]+)\)') AS OfficeLocation
FROM Dimension.Customer;

-- Returns the letter prefix, if one exists. 
SELECT
	Supplier.[Supplier Key],
	Supplier.[Supplier Reference],
	REGEXP_SUBSTR(Supplier.[Supplier Reference], '[a-zA-Z]+') AS LetterCode
FROM Dimension.Supplier;

-- Adjusting + to * allows for an empty string to be returned, instead of NULL, if not found.
SELECT
	Supplier.[Supplier Key],
	Supplier.[Supplier Reference],
	REGEXP_SUBSTR(Supplier.[Supplier Reference], '[a-zA-Z]*') AS LetterCode
FROM Dimension.Supplier;

/*	REGEXP_MATCHES: Returns a set of Regex matches, along with useful details
	This is a lot of detail and can get large if the data size is big.
*/
/*	This finds all matches where a city contains multiple sets of consecutive letter "s"
	For each match, the start position, end position, match value, and JSON with those
	details are provided for your use.
*/
SELECT
	[City Key],
	City,
	[State Province],
	RegexMatchData.*
FROM Dimension.City
CROSS APPLY REGEXP_MATCHES(City.City, '[sS]{2,}') AS RegexMatchData
WHERE REGEXP_COUNT(City.City, '[sS]{2,}') > 1
ORDER BY City.City ASC;

/*	REGEXP_SPLIT_TO_TABLE: Behaves like STRING_SPLIT, except it can be used for any Regex
	expression
*/
-- Splits on spaces:
SELECT * FROM REGEXP_SPLIT_TO_TABLE ('the quick brown fox jumps over the lazy dog', '\s+')

-- Finds cities with multiple pairs of the letter "s" and splits it on that pattern:
SELECT
	[City Key],
	City,
	[State Province],
	RegexSplitData.*
FROM Dimension.City
CROSS APPLY REGEXP_SPLIT_TO_TABLE(City.City, '[sS]{2,}') AS RegexSplitData
WHERE REGEXP_COUNT(City.City, '[sS]{2,}') > 1
ORDER BY City.City ASC;

/*	This tries to split on two characters, but doesn't work as STRING_SPLIT only accepts
	a single character as the split criteria */
SELECT
	*
FROM STRING_SPLIT('"Taco", "Pizza", "Cheeseburger", "Salad", "Apple", "Carrot"', '", "');

-- This ALMOST works, except that the double-quotes remain:
SELECT
	*
FROM REGEXP_SPLIT_TO_TABLE('"Taco", "Pizza", "Cheeseburger", "Salad", "Apple", "Carrot"', '", "');

-- This trims out the double-quotes:
SELECT
	*
FROM REGEXP_SPLIT_TO_TABLE('"Taco", "Pizza", "Cheeseburger", "Salad", "Apple", "Carrot"', '", "|^"|"$')
WHERE [value] <> '';

/*	FLAGS
		There are a variety of flags that can augment these functions. Feel free to experiement
		with them to learn their function:

	i: Case Insensitive 
	When the "i" flag is used, all string characters in the regular expression
	will be treated as case insensitive, allowing capital and lowercase letters
	to match patterns for each other. This is not a default setting. 

	c: Case Sensitive
	This forces regex pattern matching to be case sensitive. This is the default
	setting and does not need to be explicitly used to ensure case sensitive regular
	expression matching. 

	m: Multi-Line Mode
	When this flag is used, the carat (^) and dollar sign ($) will match the begin/end
	line characters in addition to begin/end text. This is not a default setting. 

	s: New Line Character Matching 
	This flag allows a period (.) to match a new line character (\n). This is not a
	default setting. Normally a period will match most characters, but not a new line.
*/

/**************************************************************************************
*******************************VECTOR Functions****************************************
***************************************************************************************/
-- BEGIN SAMPLE DATA CREATION:
CREATE TABLE dbo.Books (
	BookId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Books PRIMARY KEY CLUSTERED,
	BookTitle VARCHAR(250) NOT NULL,
	BookTitleVector VECTOR(3));

INSERT INTO dbo.Books
	(BookTitle, BookTitleVector)
VALUES
	('The Old Man and the Sea', '[0.5, 0.1, -0.1]'),
	('Moby Dick', '[0.1, 0.2, -0.1]'),
	('The Great Gatsby', '[-0.4, 0.7, 0.05]'),
	('The Hobbit', '[-0.25, 0.5, 0.03]'),
	('Lord of the Flies', '[-0.2, 0.9, 0.14]'),
	('The Catcher in the Rye', '[0.05, 0.82, 0.6]'),
	('Frankenstein', '[-0.5, 0.2, 0.8]');

CREATE VECTOR INDEX VIX_Books_BookTitleVector
ON dbo.Books (BookTitleVector)
WITH (METRIC = 'cosine', TYPE = 'diskann');

-- END SAMPLE DATA CREATION

/* VECTOR_DISTANCE: Calculates the similarity of two vectors using one of 3 algorithms
	Ordering by cosine distance is the most common way to compare vector embeddings
*/
DECLARE @Vector1 VECTOR(3) = '[-0.5, 0.8, 0.6]';
DECLARE @Vector2 VECTOR(3) = '[-0.1, 0, 0.9]';

SELECT VECTOR_DISTANCE('euclidean', @Vector1, @Vector2) AS EuclideanVectorDistance;
SELECT VECTOR_DISTANCE('dot', @Vector1, @Vector2) AS DotVectorDistance;
SELECT VECTOR_DISTANCE('cosine', @Vector1, @Vector2) AS CosineVectorDistance;
GO

DECLARE @Vector1 VECTOR(3) = '[-0.5, 0.8, 0.6]';
DECLARE @Vector2 VECTOR(3) = '[-0.5, 0.8, 0.6]';
SELECT VECTOR_DISTANCE('cosine', @Vector1, @Vector2) AS CosineVectorDistance;

DECLARE @SampleBookTitle VARCHAR(250) = 'Hobbit';
DECLARE @SampleVector VECTOR(3) = '[-0.2, 0.5, 0.051]';
SELECT
	Books.BookTitle,
	VECTOR_DISTANCE('cosine', Books.BookTitleVector, @SampleVector) AS CosineVectorDistance
FROM dbo.Books
ORDER BY CosineVectorDistance;
GO

/* VECTOR_SEARCH: Expands on VECTOR_DISTANCE, returning a table of results
	based on a variety of input instructions. Requires a vector index on
	the vector column to be searched on.
*/ 

DECLARE @SampleBookTitle VARCHAR(250) = 'Hobbit';
DECLARE @SampleVector VECTOR(3) = '[-0.2, 0.5, 0.051]';
SELECT
	*
FROM VECTOR_SEARCH (
        TABLE = [dbo].[books],
        COLUMN = [BookTitleVector],
        SIMILAR_TO = @SampleVector,
        METRIC = 'cosine',
        TOP_N = 3
) VectorSearchResults
ORDER BY VectorSearchResults.distance;

/* VECTOR_NORM: Returns the norm of a vector, which is its magnitude. This
	is used in some mathematical/statistical calculations. 'norm2' is the
	Euclidean norm, which is the most common one used. Also supported are:
	norm1: sum of absolute values of all vector components
	norminf: infinity norm - maximum of absolute values of all vector components.
*/
SELECT
	*,
	VECTOR_NORM(BookTitleVector, 'norm2') AS EuclideanNorm,
	VECTOR_NORM(BookTitleVector, 'norm1') AS Norm1,
	VECTOR_NORM(BookTitleVector, 'norminf') AS InfinityNorm
FROM dbo.Books;

/* VECTOR_NORMALIZE: Returns a normalized vector, which scales a vector so that
	a given norm type is equal to 1. Many AI models automatically do this for you,
	but if one does not, then this handles the task.

	The norm of a normalized vector will always be about 1.
*/
SELECT
	*,
	VECTOR_NORM(BookTitleVector, 'norm2') AS EuclideanNorm,
	VECTOR_NORMALIZE(BookTitleVector, 'norm2') AS NormalizedVector,
	VECTOR_NORM(VECTOR_NORMALIZE(BookTitleVector, 'norm2'), 'norm2') AS NormOfNormalizedVector
FROM dbo.Books;

/* VECTORPROPERTY: Returns a property of a vector. Currently supported are:
		Dimensions: A count of dimensions
		BaseType: The vector's base type
*/
SELECT
	*,
	VECTORPROPERTY(BookTitleVector, 'Dimensions') AS Dimensions,
	VECTORPROPERTY(BookTitleVector, 'BaseType') AS BaseType -- float16 will be supported soon.
FROM dbo.Books;

-- Cleanup
DROP TABLE dbo.Books

/**************************************************************************************
********************************JSON Functions*****************************************
***************************************************************************************/
/*	Native JSON was added in SQL Server 2022. Two new functions are available in
	SQL Server 2025	*/
/*	JSON_OBJECTAGG(): Creates a JSON object directly from SQL columns/data.
*/
-- Return a JSON object populated with table column metadata:
SELECT
	tables.name,
	JSON_OBJECTAGG(columns.name:types.name) AS ColumnData
FROM sys.tables
INNER JOIN sys.columns
ON columns.object_id = tables.object_id
INNER JOIN sys.types
ON types.user_type_id = columns.user_type_id
GROUP BY tables.name
ORDER BY tables.name;
/* NULL ON NULL adds an explcit NULL when a value is NULL
   ABSENT ON NULL removes any properties with NULL */

SELECT
	tables.name,
	JSON_OBJECTAGG(columns.name:COLUMNS.collation_name NULL ON NULL) AS ColumnData
FROM sys.tables
INNER JOIN sys.columns
ON columns.object_id = tables.object_id
GROUP BY tables.name
ORDER BY tables.name;

SELECT
	tables.name,
	JSON_OBJECTAGG(columns.name:COLUMNS.collation_name ABSENT ON NULL) AS ColumnData
FROM sys.tables
INNER JOIN sys.columns
ON columns.object_id = tables.object_id
GROUP BY tables.name
ORDER BY tables.name;

/*	JSON_ARRAYAGG(): Creates a JSON array directly from SQL columns/data.
*/
SELECT
	tables.name,
	JSON_ARRAYAGG(columns.name) AS ColumnData
FROM sys.tables
INNER JOIN sys.columns
ON columns.object_id = tables.object_id
GROUP BY tables.name
ORDER BY tables.name;

SELECT
	tables.name,
	JSON_ARRAYAGG(columns.name ORDER BY columns.name) AS ColumnData
FROM sys.tables
INNER JOIN sys.columns
ON columns.object_id = tables.object_id
GROUP BY tables.name
ORDER BY tables.name;

/*	EDIT_DISTANCE: Returns the minimum number of additions, subtractions,
	or substitutions to transform one string into another. Implemented using the
	Damerau�Levenshtein distance algorithm:
	https://en.wikipedia.org/wiki/Damerau%E2%80%93Levenshtein_distance
	Note that NULL for any input results in an output of NULL.
*/

SELECT EDIT_DISTANCE('Grandeur', 'Grander') AS EditDistance;

SELECT EDIT_DISTANCE('Edward', 'Eduardo') AS EditDistance;

SELECT EDIT_DISTANCE('SQL Server', 'Postgres') AS EditDistance;

/*	EDIT_DISTANCE_SIMILARITY: Returns a percentage indicating how similar 2 strings are.
	This is based on the string lengths and distance calculated from EDIT_DISTANCE as
	follows: (1 � (edit_distance / greatest(len(string1), len(string2)))) * 100
	Note that NULL for any input results in an output of NULL.
*/

SELECT EDIT_DISTANCE_SIMILARITY('Grandeur', 'Grander') AS SimilarityPercentage;

SELECT EDIT_DISTANCE_SIMILARITY('Edward', 'Eduardo') AS SimilarityPercentage;

SELECT EDIT_DISTANCE_SIMILARITY('SQL Server', 'Postgres') AS SimilarityPercentage;

/*	JARO_WINKLER_DISTANCE: Returns the edit distance between 2 strings with a preference
	for strings that match a prefix of characters. Uses the Jaro-Winkler distance algorithm:
	https://en.wikipedia.org/wiki/Jaro%E2%80%93Winkler_distance
*/

SELECT JARO_WINKLER_DISTANCE('Grandeur', 'Grander') AS JaroWinklerDistance;

SELECT JARO_WINKLER_DISTANCE('Edward', 'Eduardo') AS JaroWinklerDistance;

SELECT JARO_WINKLER_DISTANCE('SQL Server', 'Postgres') AS JaroWinklerDistance;

/*	JARO_WINKLER_SIMILARITY: Returns the similarity rating (0-100) between 2 strings
	with a preference for strings that match a prefix of characters.
*/

SELECT JARO_WINKLER_SIMILARITY('Grandeur', 'Grander') AS JaroWinklerSimilarity;

SELECT JARO_WINKLER_SIMILARITY('Edward', 'Eduardo') AS JaroWinklerSimilarity;

SELECT JARO_WINKLER_SIMILARITY('SQL Server', 'Postgres') AS JaroWinklerSimilarity;

/**************************************************************************************
*************************Changes to Existing Syntax************************************
***************************************************************************************/
/*	SUBSTRING: Length parameter now optional. Simplifies code! */
-- The old ways:
DECLARE @string VARCHAR(25) = 'MySpecialQuery.sql';
SELECT SUBSTRING(@string, CHARINDEX('.', @string), LEN(@string) - CHARINDEX('.', @string) + 1);

DECLARE @string VARCHAR(25) = 'MySpecialQuery.sql';
SELECT SUBSTRING(@string, CHARINDEX('.', @string), 4);

-- The new way:
DECLARE @string2 VARCHAR(25) = 'MySpecialQuery.sql';
SELECT SUBSTRING(@string2, CHARINDEX('.', @string2));

/*	DATEADD: Now supports a BIGINT for the number to be added 
	This used to throw the error: Msg 8115, Level 16, State 2, Line 1
	Arithmetic overflow error converting expression to data type int.
*/
SELECT DATEADD(MILLISECOND, 71928376123, '1/1/2025');

/*	CURRENT_DATE: Returns...you guessed it...the current date!
*/

-- The old way:
SELECT CAST(GETUTCDATE() AS DATE);

-- The new way:
SELECT CURRENT_DATE;

/*	BASE64ENCODE: Converts a VARBINARY value into a VARCHAR value.
	BASE64DECODE: Converts a VARCHAR value into a VARBINARY value. */

SELECT BASE64_DECODE('This is a VARBINARY string to convert to VARCHAR') AS VarbinaryOutput;
-- Returns 0x4E18AC8AC695011048340458B2DAE29E0B687289EF7ABB6DA15011087011

SELECT BASE64_ENCODE(0x4E18AC8AC695011048340458B2DAE29E0B687289EF7ABB6DA15011087011) AS VarcharOutput;
-- Returns ThisisaVARBINARYstringtoconverttoVARCHAR
SELECT BASE64_ENCODE(CAST ('This is the best string ever' AS VARBINARY));
-- Returns VGhpcyBpcyB0aGUgYmVzdCBzdHJpbmcgZXZlcg==

-- The optional flag indicates if the output should be URL safe:
SELECT BASE64_ENCODE(CAST ('This is the best string ever' AS VARBINARY), 1);
-- Returns VGhpcyBpcyB0aGUgYmVzdCBzdHJpbmcgZXZlcg

